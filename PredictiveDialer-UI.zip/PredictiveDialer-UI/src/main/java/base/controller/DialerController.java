package base.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zang.api.exceptions.ZangException;

import base.model.DialerData;
import base.service.DialerService;
import base.util.DialerConstants;
import base.util.DialerUtils;
import base.util.ZingConfig;

@Controller
public class DialerController {
	private static final Logger log = LogManager.getLogger(DialerController.class);

	@Autowired
	private DialerService service;

	@Autowired
	private ZingConfig zingDial;

	@GetMapping("/")
	public String homePage() {
		return "Dashboard";
	}

	@GetMapping(value = { "/welcome" })
	public String dialerDataPage(Model model) {

		List<DialerData> list = service.getAllDialerData();

		model.addAttribute("dataList", list != null ? list : new ArrayList<>());

		return "index";
	}

	@GetMapping("handledial")
	@ResponseBody
	public String dial(@RequestParam("countryCode") String countryCode, @RequestParam("number") String number) {

		try {
			zingDial.dial(countryCode, number);

			DialerData dialerData = service.findByMobile1(number);
			if (dialerData != null) {
				dialerData.setStatus(DialerConstants.DIALED);
				try {
					service.updateDialerEntity(dialerData);
					log.info("Dial status updated for :" + dialerData.getMobile1());
				} catch (Exception e) {
					log.error("Failed to update dial status");
				}
			}
			return number + " dialed successfully.";
		} catch (ZangException e) {
			e.printStackTrace();
			return "Failed to dial";
		}
	}

	@GetMapping("hangup")
	@ResponseBody
	public String hangup() {
		return "Hung up from server : ";
	}

	@PostMapping("/importcsvdata")
	public String inportData(@RequestParam("file") MultipartFile[] file, RedirectAttributes model) {
		log.info("FILE NAME-> " + file[0].getOriginalFilename());

		try {
			List<DialerData> readCsvDataList = DialerUtils.readCsvData(file[0].getInputStream());

			Boolean saveStatus = service.saveAll(readCsvDataList);
			if (saveStatus)
				log.info("CSV data saved into DB.");
			else
				log.info("CSV data couldn't save into DB.");

		} catch (IOException e) {
			e.printStackTrace();
		}

		return "redirect:/welcome";
	}

	@GetMapping("/demo")
	public void statusCallback(HttpServletRequest req) {
		log.info("INSIDE CALLBACk======================="
//	+req.getQueryString()
		);
		log.info("Call status=======================" + req.getParameter("CallStatus"));

	}

}
