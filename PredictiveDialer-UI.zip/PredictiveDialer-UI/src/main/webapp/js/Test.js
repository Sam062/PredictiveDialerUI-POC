let pattern='[0-9]';
x=x.replace('[0-9]','*');

console.log("NEW VALUE="+x);